void test_demo_0();

void exam1();
void exam2();
void exam3();
void exam4();
void exam5();
void exam6();
